  <?php
    #Let's Sharp the Blade before we Turn on the Lights
    include ('includes/app.php'); #Including the App
    include ('assets/header.php'); # Including the common header
  ?>
      <div class="jumbotron">       
        <h3>Contact</h3>
        <p><a href="http://sysaxiom.com/contact/" target="_new" style="text-decoration:none">Click here</a> to Contact the me (Sulthan Allaudeen) </p>
	  </div>
  <?php
		include ('assets/footer.php'); #Including the common footer
	?>