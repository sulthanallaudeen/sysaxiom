  <?php
    #Let's Sharp the Blade before we Turn on the Lights
    include ('includes/app.php'); #Including the App
    include ('assets/header.php'); # Including the common header
  ?>


      <div class="jumbotron">
        
                  
        <h3>Google Maps Api in PHP</h3>
        <p>This is the application which makes uses of few of the Api's Provided by Google Maps.</p>
	  </div>


      


	<?php
		include ('assets/footer.php'); #Including the common footer
	?>