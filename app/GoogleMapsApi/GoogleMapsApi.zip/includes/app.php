<?php
$url = 'http://localhost/learnings/sulthan/test/GoogleMapsApi/';
$url = 'http://sysaxiom.com/app/GoogleMapsApi/';
$StartTime = microtime(true); #Starting the Timer
?>
